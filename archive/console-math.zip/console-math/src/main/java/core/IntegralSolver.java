package core;

import java.util.function.Function;

/**
 * @author Arthur Kupriyanov on 18.03.2020
 */
public interface IntegralSolver {
    double solve(Function<Double, Double> function, int top, int bottom, int partition);
}
