package core.impl;

import core.IntegralSolver;

import java.util.function.Function;

/**
 * @author Arthur Kupriyanov on 18.03.2020
 */
public class SimpsonSolverExtended implements IntegralSolver {
    private final SimpsonSolver SOLVER = new SimpsonSolver();

    private volatile Double lastAccuracy;
    private volatile Integer lastPartition;

    public double solveWithAccuracy(Function<Double, Double> function, int top, int bottom, double expectedAccuracy){
        int partition = 10;
        double actualAccuracy = Double.MAX_VALUE;
        double oldValue = solve(function, top, bottom, partition);
        while (actualAccuracy > expectedAccuracy) {

            partition = partition * 2;
            double actualValue = solve(function, top, bottom, partition);
            actualAccuracy = Math.abs(actualValue - oldValue) / 15; // 2^4 - 1
            oldValue = actualValue;

        }
        lastAccuracy = actualAccuracy;
        lastPartition = partition;
        return oldValue;
    }

    @Override
    public double solve(Function<Double, Double> function, int top, int bottom, int partition) {
        return SOLVER.solve(function, top, bottom, partition);
    }

    public Double getLastAccuracy() {
        return lastAccuracy;
    }

    public Integer getLastPartition() {
        return lastPartition;
    }
}
