package core;

/**
 * @author Arthur Kupriyanov on 28.02.2020
 */
public interface MatrixSolver{

    float getDeterminant();
    float[] solve();
}
