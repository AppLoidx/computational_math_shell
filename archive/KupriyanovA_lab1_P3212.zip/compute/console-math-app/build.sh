#!/bin/bash
mvn clean package
clear
./run.sh