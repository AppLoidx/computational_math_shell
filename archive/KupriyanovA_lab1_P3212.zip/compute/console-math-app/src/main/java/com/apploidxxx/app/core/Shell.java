package com.apploidxxx.app.core;

/**
 * @author Arthur Kupriyanov on 18.02.2020
 */
public interface Shell {

    public abstract void run() throws Exception;
}
