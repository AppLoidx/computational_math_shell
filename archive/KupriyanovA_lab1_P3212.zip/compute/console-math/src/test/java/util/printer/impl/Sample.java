package util.printer.impl;

/**
 * @author Arthur Kupriyanov on 04.03.2020
 */

public class Sample {

}
