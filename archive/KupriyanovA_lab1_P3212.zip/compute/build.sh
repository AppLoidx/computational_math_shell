#!/bin/bash
mvn clean package
java -jar console-math-app/target/console-math-app-1.0-SNAPSHOT-jar-with-dependencies.jar