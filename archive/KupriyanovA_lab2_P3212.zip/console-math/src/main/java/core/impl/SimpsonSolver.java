package core.impl;

import core.IntegralSolver;

import java.util.function.Function;

/**
 * @author Arthur Kupriyanov on 18.03.2020
 */
public class SimpsonSolver implements IntegralSolver {
    @Override
    public double solve(Function<Double, Double> function, int top, int bottom, int partition) {
        int[] boundaries = new int[2];
        addBoundariesTo(boundaries, top, bottom);

        double step = (boundaries[1] - boundaries[0] * 1d) / partition;

        double sum1 = 0;
        double sum2 = 0;

        for (int i = 0; i < partition; i++) {
            double functionValue = function.apply(boundaries[0] + i * step);
            if (i % 2 == 0) {
                sum1 = sum1 + functionValue;
            } else {
                sum2 = sum2 + functionValue;
            }
        }
        byte sign = (byte) (top > bottom ? 1 : -1);
        return sign * step / 3 * (function.apply((double) boundaries[0]) + function.apply((double) boundaries[1]) + 2 * sum1 + 4 * sum2);
    }

    private void addBoundariesTo(int[] boundaries, int top, int bottom){
        boundaries[0] = Math.min(top, bottom);
        boundaries[1] = Math.max(top, bottom);
    }

}
