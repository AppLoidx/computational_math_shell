#!/bin/bash
java -jar target/console-math-app-1.0-SNAPSHOT-jar-with-dependencies.jar