package com.apploidxxx.app.core.command.impl;

import com.apploidxxx.app.console.Console;
import com.apploidxxx.app.core.command.Command;
import com.apploidxxx.app.core.command.stereotype.Executable;
import core.impl.SimpsonSolverExtended;

import java.io.IOException;
import java.util.function.Function;

/**
 * @author Arthur Kupriyanov on 19.03.2020
 */
@Executable("integral")
public class Integral implements Command {

    private static final Function<Double, Double> FUNCTION_1 = x -> 2 * x * x;
    private static final Function<Double, Double> FUNCTION_2 = x -> 3 * x * x + 8 * x + 8;
    private static final Function<Double, Double> FUNCTION_3 = x -> 3/4d * x;
    private static final Function<Double, Double> FUNCTION_4 = Math::sqrt;
    private static final Function<Double, Double> FUNCTION_5 = x -> Math.sqrt(x) * x;

    private static final String FUNCTION_1_NAME = "2x^2";
    private static final String FUNCTION_2_NAME = "3x^2 + 8x + 8";
    private static final String FUNCTION_3_NAME = "3x/4";
    private static final String FUNCTION_4_NAME = "sqrt(x)";
    private static final String FUNCTION_5_NAME = "x * sqrt(x)";

    private static final String[] funcNames = new String[]{
            FUNCTION_1_NAME,
            FUNCTION_2_NAME,
            FUNCTION_3_NAME,
            FUNCTION_4_NAME,
            FUNCTION_5_NAME
    } ;

    @Override
    public void execute(Console console, String context) throws Exception {

        console.clearScreen();

        int funcNumber = readFuncNumber(console);
        Function<Double, Double> function = getFunction(funcNumber, console);

        console.clearScreen();
        printInfo(funcNames[funcNumber - 1], console);

        console.println("-----------------------------");
        double accuracy = readAccuracy(console);

        console.clearScreen();
        printInfo(funcNames[funcNumber - 1], accuracy, console);

        console.println("-----------------------------");
        console.print("Введите верхний предел: ");
        int top = readInt(console);
        console.println("");
        console.print("Введите нижний предел: ");
        int bottom = readInt(console);

        console.clearScreen();
        printInfo(funcNames[funcNumber - 1], accuracy, top, bottom, console);

        try {
            SimpsonSolverExtended solverExtended = new SimpsonSolverExtended();
            double answer = solverExtended.solveWithAccuracy(function, top, bottom, accuracy);

            console.println("-----------------------------");
            console.println("Ответ: " + answer);
            console.println("Точность: " + solverExtended.getLastAccuracy());
            console.println("Количество частей: " + solverExtended.getLastPartition());
        } catch (StackOverflowError | OutOfMemoryError e) {
            console.println("\nНе хватает вычислительной мощности для поулчения ответа!");
            console.println("Попробуйте в следующий раз снизить точность");
        }
    }

    private int readInt(Console console) throws IOException {
        try {
            return Integer.parseInt(console.readLine());
        } catch (NumberFormatException e) {
            console.println("Введите цело число в области значений int");
            return readInt(console);
        }
    }

    private double readAccuracy(Console console) throws IOException {
        console.println("Введите точность необходимую точность ответа: ");
        try {
            return Double.parseDouble(console.readLine());
        } catch (NumberFormatException e){
            console.println("Введите верный формат точности!");
            return readAccuracy(console);
        }
    }

    private int readFuncNumber(Console console) throws IOException {
        console.println("Введите номер функции");
        console.println("[1] 2x^2\n" +
                        "[2] 3x^2 + 8x + 8\n" +
                        "[3] 3x/4\n" +
                        "[4] sqrt(x)\n" +
                        "[5] x * sqrt(x)");
        console.println("__________________________________");
        int number = console.readInt();
        if (number < 1 || number > 5) {
            console.println("Выберите число от 1 до 5");
            return readFuncNumber(console);
        } else {
            return number;
        }
    }

    private Function<Double, Double> getFunction(int number, Console console){

        switch (number){
            case 1: return FUNCTION_1;
            case 2: return FUNCTION_2;
            case 3: return FUNCTION_3;
            case 4: return FUNCTION_4;
            case 5: return FUNCTION_5;
            default: return null;
        }
    }

    private void printInfo(String function, Console console){
        console.println("Функция: " + function);
    }

    private void printInfo(String function, double accuracy, Console console){
        printInfo(function, console);
        console.println(String.format("Точность: %f", accuracy));
    }

    private void printInfo(String function, double accuracy, int top, int bottom, Console console) {
        printInfo(function, accuracy, console);
        console.println("Верхний предел: " + top);
        console.println("Нижний предел: " + bottom);
    }
}
